<!DOCTYPE html>
<html>
<head>
<title>Redirecting...</title>
<meta charset="utf-8">
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="REFRESH" content="5;URL=<?php echo $_GET['url'];?>">
<script type="text/javascript" src="js/jquery.js">
</script>
<script type="text/javascript" src="js/jquery-ui.min.js">
</script>
<script type="text/javascript" src="js/bootstrap.min.js">
</script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet"  href="bootstrap.css" type="text/css" media="screen"/>
<link rel="stylesheet"  href="rtl.css" type="text/css" media="screen"/>
<!--[if lte IE 8]>
<link rel="stylesheet"  href="menuie.css" type="text/css" media="screen"/>
<link rel="stylesheet"  href="vmenuie.css" type="text/css" media="screen"/>
<![endif]-->
<!--[if IE 7]>
<style type="text/css" media="screen">
#ttr_vmenu_items  li.ttr_vmenu_items_parent {margin-left:-16px;font-size:0px;}
</style>
<![endif]-->
<!--[if lt IE 9]>
<script type="text/javascript" src="js/html5shiv.js">
</script>
<script type="text/javascript" src="js/respond.min.js">
</script>
<![endif]-->

</head>
<body class="index" style="position: absolute; height: 100%; width: 100%; left: 0px; top: 0px;">
<div id="ttr_page" class="container">
<div id="ttr_content_and_sidebar_container">
<div id="ttr_content">
<div id="ttr_content_margin"class="container-fluid">
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
<div class="ttr_index_html_row0 row">
<div class="post_column col-lg-12 col-md-12 col-sm-12 col-xs-12">
<div class="ttr_index_html_column00">
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
<div class="html_content"><p style="text-align:Center;"><br /></p><p style="text-align:Center;"><span style="font-size:3.571em;">در حال انتقال به لینک جدید !</span></p><p style="text-align:Center;"><span style="font-size:3.643em;">‌</span></p><p style="text-align:Center;"><span style="font-size:2.357em;">شما تا 5 ثانیه آینده به لینک زیر هدایت خواهید شد :</span></p><p style="text-align:Center;"><span style="font-size:2.357em;"><?php echo $_GET['url'];?></span></p><p style="text-align:Center;"><span style="font-size:2.429em;">‌</span></p><p style="text-align:Center;"><span style="font-size:1.929em;">در صورتی که هدایت بطور خودکار انجام نشد ، بر روی دکمه زیر کلیک کنید :</span></p><p style="text-align:Center;"><span><a HREF="<?php echo $_GET['url'];?>" target="_self" class="btn btn-lg btn-success">ورود</a></span></p><p style="text-align:Center;"><br style="font-size:1.929em;" /></p></div>
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
<div style="clear:both;"></div>
</div>
</div>
<div class="clearfix visible-lg-block visible-sm-block visible-md-block visible-xs-block">
</div>
</div>
<div style="height:0px;width:0px;overflow:hidden;-webkit-margin-top-collapse: separate;"></div>
</div>
</div>
<div style="clear:both">
</div>
</div>
</div>
</body>
</html>