<!DOCTYPE html>
<html>
<body>

<script>
$(document).ready(function(){
   $("#nameID").keyup(function(){  
   var name = $("#nameID").val();
   $("#screen-name").text(name);
    
    });
});
</script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<p class="editor-example" id="screen-name">Name</p>

<form id="info">                    
<input id="nameID" name="name" type="text" size="20">
</form>
<button id="apply" type="button">Apply</button>

</body>
</html>
